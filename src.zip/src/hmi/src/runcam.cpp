#include "runcam.h"

runcam::runcam(){}

void runcam::run(){
    //system("ros2 run detect detect_node");
}