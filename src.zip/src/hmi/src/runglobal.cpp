#include "runglobal.h"

runglobal::runglobal() {}

void runglobal::run() {
    system(" ros2 run global  global_node ");
}
