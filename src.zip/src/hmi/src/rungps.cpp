#include "rungps.h"

rungps::rungps() {}

void rungps::run() {
    //system("ros2 run gnss gnss_node");
}
