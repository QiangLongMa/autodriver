#include "runcontrol.h"

runcontrol::runcontrol() {}

void runcontrol::run() {
    system(" ros2 run control control_node ");
}
